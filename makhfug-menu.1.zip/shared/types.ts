/**
 * Unified type exports
 * Import shared types from this single entry point.
 */

export type * from "../drizzle/schema";
export * from "./_core/errors";

// Custom types for menu items
export interface MenuItemWithSizes {
  id: number;
  categoryId: number;
  nameAr: string;
  nameEn: string;
  descriptionAr?: string;
  descriptionEn?: string;
  imageUrl?: string;
  calories?: number;
  isActive: boolean;
  order: number;
  sizes: Array<{
    id: number;
    itemId: number;
    sizeAr: string;
    sizeEn: string;
    price: string;
    order: number;
    isActive: boolean;
  }>;
}

export interface CategoryWithItems {
  id: number;
  nameAr: string;
  nameEn: string;
  description?: string;
  order: number;
  isActive: boolean;
  items: MenuItemWithSizes[];
}
