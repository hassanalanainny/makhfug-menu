import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { type Item, type Size } from "@shared/types";

interface ItemCardProps {
  item: Item & { sizes: Size[] };
  index: number;
}

export default function ItemCard({ item, index }: ItemCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 bg-white border-2 border-green-100 hover:border-green-400 group">
        {/* Item Image Container */}
        <motion.div
          className="relative h-48 bg-gradient-to-br from-green-100 to-yellow-100 overflow-hidden"
          whileHover={{ scale: 1.05 }}
          transition={{ duration: 0.3 }}
        >
          {item.imageUrl ? (
            <motion.img
              src={item.imageUrl}
              alt={item.nameAr}
              className="w-full h-full object-cover"
              whileHover={{ scale: 1.1 }}
              transition={{ duration: 0.3 }}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <span className="text-gray-400">صورة غير متاحة</span>
            </div>
          )}

          {/* Calorie Badge with Animation */}
          {item.calories && (
            <motion.div
              className="absolute top-2 right-2 bg-gradient-to-r from-purple-600 to-purple-700 text-white px-3 py-1 rounded-full text-sm font-semibold shadow-lg"
              initial={{ scale: 0, rotate: -180 }}
              whileInView={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 200, damping: 15 }}
              viewport={{ once: true }}
            >
              {item.calories} سعرة
            </motion.div>
          )}

          {/* Overlay on Hover */}
          <motion.div
            className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300"
            initial={{ opacity: 0 }}
            whileHover={{ opacity: 1 }}
          />
        </motion.div>

        {/* Item Details */}
        <div className="p-4">
          <motion.h3
            className="text-xl font-bold text-green-700 mb-2"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            {item.nameAr}
          </motion.h3>

          {item.descriptionAr && (
            <motion.p
              className="text-gray-600 text-sm mb-4 line-clamp-2"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              {item.descriptionAr}
            </motion.p>
          )}

          {/* Sizes and Prices with Stagger Animation */}
          <div className="space-y-2 mb-4">
            {item.sizes && item.sizes.length > 0 ? (
              item.sizes.map((size, sizeIndex) => (
                <motion.div
                  key={size.id}
                  className="flex justify-between items-center p-2 bg-yellow-50 rounded-lg border border-yellow-200 hover:border-yellow-400 hover:bg-yellow-100 transition-colors"
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + sizeIndex * 0.1 }}
                  whileHover={{ x: 5 }}
                >
                  <span className="font-semibold text-gray-700">
                    {size.sizeAr}
                  </span>
                  <motion.span
                    className="text-green-600 font-bold text-lg"
                    whileHover={{ scale: 1.1 }}
                  >
                    {size.price} ر.س
                  </motion.span>
                </motion.div>
              ))
            ) : (
              <div className="text-gray-500 text-sm">
                لا توجد أحجام متاحة
              </div>
            )}
          </div>

          {/* Order Button with Animation */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Button className="w-full bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white font-semibold shadow-lg hover:shadow-xl transition-shadow">
              اطلب الآن
            </Button>
          </motion.div>
        </div>
      </Card>
    </motion.div>
  );
}
