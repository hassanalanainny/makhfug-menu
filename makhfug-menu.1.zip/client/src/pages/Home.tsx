import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Loader2, Search, LogOut, Settings } from "lucide-react";
import { Link } from "wouter";
import ItemCard from "@/components/ItemCard";

export default function Home() {
  const { user, logout } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);

  const { data: menuData, isLoading } = trpc.menu.getCategories.useQuery();

  const filteredMenu = useMemo(() => {
    if (!menuData) return [];

    let filtered: typeof menuData = menuData;

    if (selectedCategory) {
      filtered = filtered.filter(cat => cat.id === selectedCategory);
    }

    if (searchTerm) {
      filtered = filtered.map((cat: any) => ({
        ...cat,
        items: cat.items.filter(
          (item: any) =>
            item.nameAr.includes(searchTerm) ||
            item.descriptionAr?.includes(searchTerm)
        ),
      }));
    }

    return filtered;
  }, [menuData, searchTerm, selectedCategory]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-yellow-300 to-yellow-200">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-green-600 mx-auto mb-4" />
          <p className="text-gray-700 font-semibold">جاري تحميل المنيو...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-300 via-yellow-200 to-yellow-100">
      {/* Header */}
      <motion.header
        className="sticky top-0 z-50 bg-white shadow-lg"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-teal-600 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-lg">م</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-green-700">مخفوق</h1>
              <p className="text-xs text-gray-600">منيو رقمي</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {user ? (
              <>
                {user.role === "admin" && (
                  <Link href="/admin">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="gap-2 text-green-600 hover:text-green-700"
                    >
                      <Settings className="w-4 h-4" />
                      لوحة التحكم
                    </Button>
                  </Link>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => logout()}
                  className="gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  تسجيل الخروج
                </Button>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button className="bg-green-600 hover:bg-green-700">
                  تسجيل الدخول
                </Button>
              </a>
            )}
          </div>
        </div>

        {/* Search Bar */}
        <div className="border-t border-gray-200 py-3" style={{paddingTop: '14px'}}>
          <div className="container mx-auto px-4">
            <div className="relative">
              <Search className="absolute right-3 top-3 w-5 h-5 text-gray-400" />
              <Input
                placeholder="ابحث عن الأصناف..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="pr-10 border-2 border-green-200 focus:border-green-500"
              />
            </div>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Categories Tabs */}
        {menuData && menuData.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            <Tabs
              defaultValue={`category-${menuData[0]?.id}`}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2 mb-8 bg-white/80 backdrop-blur p-2 rounded-lg">
                {menuData.map((category: any) => (
                  <TabsTrigger
                    key={category.id}
                    value={`category-${category.id}`}
                    onClick={() => setSelectedCategory(category.id)}
                    className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500 data-[state=active]:to-teal-600 data-[state=active]:text-white" style={{fontSize: '17px', paddingLeft: '6px', marginTop: '2px', marginBottom: '4px', marginLeft: '1px', width: '293px', borderStyle: 'dashed'}} style={{paddingTop: '0px', paddingRight: '17px', paddingLeft: '4px'}} style={{display: 'block', opacity: '1.3'}}
                  >
                    {category.nameAr}
                  </TabsTrigger>
                ))}
              </TabsList>

              {/* Items Grid */}
              {filteredMenu.map((category: any) => (
                <TabsContent
                  key={category.id}
                  value={`category-${category.id}`}
                  className="space-y-8"
                >
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                  >
                    <h2 className="text-3xl font-bold text-green-700 mb-6">
                      {category.nameAr}
                    </h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {category.items.map((item: any, index: number) => (
                        <ItemCard key={item.id} item={item} index={index} />
                      ))}
                    </div>

                    {category.items.length === 0 && (
                      <div className="text-center py-12">
                        <p className="text-gray-500 text-lg">
                          لا توجد أصناف في هذه الفئة
                        </p>
                      </div>
                    )}
                  </motion.div>
                </TabsContent>
              ))}
            </Tabs>
          </motion.div>
        )}

        {/* Empty State */}
        {(!menuData || menuData.length === 0) && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">لا توجد أصناف متاحة حالياً</p>
          </div>
        )}
      </main>

      {/* Footer */}
      <motion.footer
        className="bg-green-700 text-white py-8 mt-12"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        viewport={{ once: true }}
      >
        <div className="container mx-auto px-4 text-center">
          <p className="text-lg font-semibold mb-2">مخفوق - منيو رقمي احترافي</p>
          <p className="text-green-100">جميع الحقوق محفوظة © 2026</p>
        </div>
      </motion.footer>
    </div>
  );
}
