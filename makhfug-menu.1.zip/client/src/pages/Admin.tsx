import { useState } from "react";
import { motion } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Link } from "wouter";
import { ArrowLeft, Users, TrendingUp, Package } from "lucide-react";

export default function Admin() {
  const { user, logout } = useAuth();
  const { data: analytics } = trpc.admin.getAnalytics.useQuery();

  // Check if user is admin
  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-yellow-300 to-yellow-200">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="p-8 text-center">
            <h1 className="text-2xl font-bold text-red-600 mb-4">غير مصرح</h1>
            <p className="text-gray-600 mb-6">ليس لديك صلاحيات الوصول لهذه الصفحة</p>
            <Link href="/">
              <Button className="bg-green-600 hover:bg-green-700">
                العودة للرئيسية
              </Button>
            </Link>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-300 via-yellow-200 to-yellow-100">
      {/* Header */}
      <motion.header
        className="bg-white shadow-lg"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                العودة
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-green-700">لوحة التحكم</h1>
          </div>
          <Button 
            variant="outline"
            onClick={() => logout()}
          >
            تسجيل الخروج
          </Button>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <Tabs defaultValue="dashboard" className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-8 bg-white/80 backdrop-blur p-2 rounded-lg">
              <TabsTrigger value="dashboard" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
                لوحة المعلومات
              </TabsTrigger>
              <TabsTrigger value="items" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
                الأصناف
              </TabsTrigger>
              <TabsTrigger value="categories" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
                الفئات
              </TabsTrigger>
              <TabsTrigger value="settings" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
                الإعدادات
              </TabsTrigger>
            </TabsList>

            {/* Dashboard Tab */}
            <TabsContent value="dashboard" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Stats Cards */}
                {[
                  {
                    icon: Package,
                    label: "إجمالي الأصناف",
                    value: analytics?.length || 0,
                    color: "green",
                    borderColor: "border-green-200",
                    bgColor: "bg-green-100",
                    textColor: "text-green-700",
                    iconColor: "text-green-600",
                  },
                  {
                    icon: TrendingUp,
                    label: "إجمالي المشاهدات",
                    value: analytics?.reduce((sum, a) => sum + (a.viewCount || 0), 0) || 0,
                    color: "purple",
                    borderColor: "border-purple-200",
                    bgColor: "bg-purple-100",
                    textColor: "text-purple-700",
                    iconColor: "text-purple-600",
                  },
                  {
                    icon: Users,
                    label: "إجمالي النقرات",
                    value: analytics?.reduce((sum, a) => sum + (a.clickCount || 0), 0) || 0,
                    color: "yellow",
                    borderColor: "border-yellow-200",
                    bgColor: "bg-yellow-100",
                    textColor: "text-yellow-700",
                    iconColor: "text-yellow-600",
                  },
                ].map((stat, index) => {
                  const Icon = stat.icon;
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      viewport={{ once: true }}
                    >
                      <Card className={`p-6 bg-white border-2 ${stat.borderColor} hover:shadow-lg transition-shadow`}>
                        <div className="flex items-center gap-4">
                          <motion.div
                            className={`p-3 ${stat.bgColor} rounded-lg`}
                            whileHover={{ scale: 1.1 }}
                          >
                            <Icon className={`w-6 h-6 ${stat.iconColor}`} />
                          </motion.div>
                          <div>
                            <p className="text-gray-600 text-sm">{stat.label}</p>
                            <motion.p
                              className={`text-3xl font-bold ${stat.textColor}`}
                              initial={{ scale: 0 }}
                              whileInView={{ scale: 1 }}
                              transition={{ type: "spring", stiffness: 200 }}
                              viewport={{ once: true }}
                            >
                              {stat.value}
                            </motion.p>
                          </div>
                        </div>
                      </Card>
                    </motion.div>
                  );
                })}
              </div>

              {/* Chart */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                viewport={{ once: true }}
              >
                <Card className="p-6 bg-white border-2 border-green-200">
                  <h3 className="text-xl font-bold text-green-700 mb-4">إحصائيات المشاهدات</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={analytics || []}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="itemId" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="viewCount" fill="#00BFA5" name="المشاهدات" />
                      <Bar dataKey="clickCount" fill="#9C27B0" name="النقرات" />
                    </BarChart>
                  </ResponsiveContainer>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Items Tab */}
            <TabsContent value="items" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-green-700">إدارة الأصناف</h2>
                <Button className="bg-green-600 hover:bg-green-700">
                  إضافة صنف جديد
                </Button>
              </div>
              
              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                viewport={{ once: true }}
              >
                <Card className="p-6 bg-white border-2 border-green-200">
                  <p className="text-gray-600">سيتم إضافة جدول الأصناف هنا قريباً...</p>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Categories Tab */}
            <TabsContent value="categories" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-green-700">إدارة الفئات</h2>
                <Button className="bg-green-600 hover:bg-green-700">
                  إضافة فئة جديدة
                </Button>
              </div>
              
              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                viewport={{ once: true }}
              >
                <Card className="p-6 bg-white border-2 border-green-200">
                  <p className="text-gray-600">سيتم إضافة جدول الفئات هنا قريباً...</p>
                </Card>
              </motion.div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="space-y-6">
              <h2 className="text-2xl font-bold text-green-700">الإعدادات</h2>
              
              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                viewport={{ once: true }}
              >
                <Card className="p-6 bg-white border-2 border-green-200">
                  <p className="text-gray-600">سيتم إضافة الإعدادات هنا قريباً...</p>
                </Card>
              </motion.div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>
    </div>
  );
}
