import { drizzle } from "drizzle-orm/mysql2";
import { categories, items, sizes } from "./drizzle/schema";
import { getDb } from "./server/db";

const seedData = async () => {
  try {
    const db = await getDb();
    if (!db) {
      console.error("فشل الاتصال بقاعدة البيانات");
      process.exit(1);
    }

    // إضافة الفئات
    const categoryData = [
      { nameAr: "عصائر طبيعية", nameEn: "Natural Juices", description: "عصائر طازة طبيعية 100%", order: 1 },
      { nameAr: "عصائر بالقهوة", nameEn: "Coffee Juices", description: "عصائر مع القهوة المختصة", order: 2 },
      { nameAr: "بروتين", nameEn: "Protein", description: "مشروبات غنية بالبروتين", order: 3 },
      { nameAr: "كوكتيلات مخفوق", nameEn: "Makhfug Cocktails", description: "مشروبات مخفوق الخاصة", order: 4 },
      { nameAr: "ملك الشيك", nameEn: "Shake King", description: "مشروبات الشيك المميزة", order: 5 },
      { nameAr: "سلطات الفواكه", nameEn: "Fruit Salads", description: "سلطات فواكه طازة", order: 6 },
      { nameAr: "آيس كريم", nameEn: "Ice Cream", description: "آيس كريم بنكهات مختلفة", order: 7 },
      { nameAr: "قهوة مختصة", nameEn: "Specialty Coffee", description: "قهوة عالية الجودة", order: 8 },
      { nameAr: "مشروبات ساخنة", nameEn: "Hot Drinks", description: "مشروبات ساخنة متنوعة", order: 9 },
      { nameAr: "حلويات", nameEn: "Desserts", description: "حلويات لذيذة", order: 10 },
    ];

    const insertedCategories = [];
    for (const cat of categoryData) {
      const result = await db.insert(categories).values(cat);
      insertedCategories.push({ ...cat, id: (result as any)[0].insertId });
    }

    console.log("✓ تم إضافة الفئات");

    // إضافة الأصناف
    const itemsData = [
      // عصائر طبيعية
      { categoryId: insertedCategories[0].id, nameAr: "برتقال", nameEn: "Orange", descriptionAr: "عصير برتقال طازة", calories: 120, order: 1 },
      { categoryId: insertedCategories[0].id, nameAr: "شمام", nameEn: "Melon", descriptionAr: "عصير شمام منعش", calories: 100, order: 2 },
      { categoryId: insertedCategories[0].id, nameAr: "بطيخ", nameEn: "Watermelon", descriptionAr: "عصير بطيخ بارد", calories: 80, order: 3 },
      { categoryId: insertedCategories[0].id, nameAr: "ليمون نعناع", nameEn: "Lemon Mint", descriptionAr: "عصير ليمون مع نعناع", calories: 90, order: 4 },
      
      // عصائر بالقهوة
      { categoryId: insertedCategories[1].id, nameAr: "أفوكادو بالقهوة", nameEn: "Avocado Coffee", descriptionAr: "مزيج فريد من الأفوكادو والقهوة", calories: 250, order: 1 },
      { categoryId: insertedCategories[1].id, nameAr: "موز بالقهوة", nameEn: "Banana Coffee", descriptionAr: "قهوة مع موز ناعم", calories: 200, order: 2 },
      
      // بروتين
      { categoryId: insertedCategories[2].id, nameAr: "بروتين فانيلا", nameEn: "Vanilla Protein", descriptionAr: "مشروب بروتين بنكهة الفانيلا", calories: 180, order: 1 },
      { categoryId: insertedCategories[2].id, nameAr: "بروتين شوكولاتة", nameEn: "Chocolate Protein", descriptionAr: "مشروب بروتين بنكهة الشوكولاتة", calories: 200, order: 2 },
      
      // كوكتيلات مخفوق
      { categoryId: insertedCategories[3].id, nameAr: "مخفوق فلو", nameEn: "Makhfug Flow", descriptionAr: "مشروب مخفوق بمكونات طبيعية", calories: 220, order: 1 },
      { categoryId: insertedCategories[3].id, nameAr: "مخفوق فيتافويت", nameEn: "Makhfug Vitavoit", descriptionAr: "مشروب صحي غني بالفيتامينات", calories: 200, order: 2 },
      
      // ملك الشيك
      { categoryId: insertedCategories[4].id, nameAr: "شيك ملك كلاسيك", nameEn: "Classic Shake", descriptionAr: "شيك كلاسيكي لذيذ", calories: 280, order: 1 },
      { categoryId: insertedCategories[4].id, nameAr: "شيك ملك أوريو", nameEn: "Oreo Shake", descriptionAr: "شيك بنكهة الأوريو", calories: 300, order: 2 },
    ];

    const insertedItems = [];
    for (const item of itemsData) {
      const result = await db.insert(items).values(item);
      insertedItems.push({ ...item, id: (result as any)[0].insertId });
    }

    console.log("✓ تم إضافة الأصناف");

    // إضافة الأحجام والأسعار
    const sizesData = [];
    for (const item of insertedItems) {
      sizesData.push(
        { itemId: item.id, sizeAr: "صغير", sizeEn: "Small", price: "10.00", order: 1 },
        { itemId: item.id, sizeAr: "وسط", sizeEn: "Medium", price: "15.00", order: 2 },
        { itemId: item.id, sizeAr: "كبير", sizeEn: "Large", price: "20.00", order: 3 }
      );
    }

    for (const size of sizesData) {
      await db.insert(sizes).values(size);
    }

    console.log("✓ تم إضافة الأحجام والأسعار");
    console.log("✓ تم إضافة جميع البيانات التجريبية بنجاح!");
    process.exit(0);
  } catch (error) {
    console.error("خطأ:", error);
    process.exit(1);
  }
};

seedData();
