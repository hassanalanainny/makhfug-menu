import { getDb } from "./server/db";
import { items } from "./drizzle/schema";
import { eq } from "drizzle-orm";

const imageUrls = [
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663100910024/eLNAjrehu9Qzn7CJUfDerm/Hrjh4yBCX75A_f46b609c.jpg",
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663100910024/eLNAjrehu9Qzn7CJUfDerm/GS9mnGeqyxwt_5b54f912.jpg",
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663100910024/eLNAjrehu9Qzn7CJUfDerm/QxfonScvp3jA_61ec7c8d.jpg",
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663100910024/eLNAjrehu9Qzn7CJUfDerm/Wf9nW8TXnQxk_f4048f4c.jpg",
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663100910024/eLNAjrehu9Qzn7CJUfDerm/a1KMoUU1Skft_660c1c2c.jpg",
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663100910024/eLNAjrehu9Qzn7CJUfDerm/eM5qLqgrYQTC_b8a42d83.jpg",
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663100910024/eLNAjrehu9Qzn7CJUfDerm/rhZlt60fqHPu_c1963614.jpg",
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663100910024/eLNAjrehu9Qzn7CJUfDerm/OwEncQgTTFQv_d0cfe2e0.jpg",
];

const updateImages = async () => {
  try {
    const db = await getDb();
    if (!db) {
      console.error("فشل الاتصال بقاعدة البيانات");
      process.exit(1);
    }

    // الحصول على جميع الأصناف
    const allItems = await db.select().from(items);
    
    // تحديث الصور بشكل دوري
    for (let i = 0; i < allItems.length; i++) {
      const imageUrl = imageUrls[i % imageUrls.length];
      await db.update(items).set({ imageUrl }).where(eq(items.id, allItems[i].id));
    }

    console.log(`✓ تم تحديث صور ${allItems.length} صنف`);
    process.exit(0);
  } catch (error) {
    console.error("خطأ:", error);
    process.exit(1);
  }
};

updateImages();
