import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { getAllCategories, getItemsByCategory, getSizesByItem, getAnalytics, recordItemView } from "./db";
import { z } from "zod";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ==================== Menu Router ====================
  menu: router({
    // الحصول على جميع الفئات والأصناف
    getCategories: publicProcedure.query(async () => {
      const categories = await getAllCategories();
      
      // الحصول على الأصناف لكل فئة
      const categoriesWithItems = await Promise.all(
        categories.map(async (category) => {
          const categoryItems = await getItemsByCategory(category.id);
          
          // الحصول على الأحجام والأسعار لكل صنف
          const itemsWithSizes = await Promise.all(
            categoryItems.map(async (item) => {
              const itemSizes = await getSizesByItem(item.id);
              return {
                ...item,
                sizes: itemSizes,
              };
            })
          );
          
          return {
            ...category,
            items: itemsWithSizes,
          };
        })
      );
      
      return categoriesWithItems;
    }),

    // تسجيل مشاهدة صنف
    recordView: publicProcedure
      .input(z.object({ itemId: z.number() }))
      .mutation(async ({ input }) => {
        await recordItemView(input.itemId);
        return { success: true };
      }),
  }),

  // ==================== Admin Router ====================
  admin: router({
    // الحصول على الإحصائيات
    getAnalytics: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== 'admin') {
        throw new Error('Unauthorized');
      }
      return getAnalytics();
    }),
  }),
});

export type AppRouter = typeof appRouter;
