import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import { getDb } from "./db";
import { categories, items, sizes } from "../drizzle/schema";

describe("Menu Router", () => {
  let db: any;

  beforeAll(async () => {
    db = await getDb();
  });

  describe("menu.getCategories", () => {
    it("should return all categories with items and sizes", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.menu.getCategories();

      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThan(0);

      // Check category structure
      result.forEach(category => {
        expect(category).toHaveProperty("id");
        expect(category).toHaveProperty("nameAr");
        expect(category).toHaveProperty("items");
        expect(Array.isArray(category.items)).toBe(true);

        // Check item structure
        category.items.forEach(item => {
          expect(item).toHaveProperty("id");
          expect(item).toHaveProperty("nameAr");
          expect(item).toHaveProperty("sizes");
          expect(Array.isArray(item.sizes)).toBe(true);

          // Check size structure
          item.sizes.forEach(size => {
            expect(size).toHaveProperty("id");
            expect(size).toHaveProperty("sizeAr");
            expect(size).toHaveProperty("price");
          });
        });
      });
    });

    it("should have at least one category with items", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.menu.getCategories();

      const categoriesWithItems = result.filter(cat => cat.items.length > 0);
      expect(categoriesWithItems.length).toBeGreaterThan(0);
    });

    it("should have prices in correct format", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.menu.getCategories();

      result.forEach(category => {
        category.items.forEach(item => {
          item.sizes.forEach(size => {
            // Price should be a valid number string
            const price = parseFloat(size.price);
            expect(isNaN(price)).toBe(false);
            expect(price).toBeGreaterThan(0);
          });
        });
      });
    });
  });

  describe("menu.recordView", () => {
    it("should record item view successfully", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      // Get first item
      const categories = await caller.menu.getCategories();
      const firstItem = categories[0]?.items[0];

      if (firstItem) {
        const result = await caller.menu.recordView({ itemId: firstItem.id });
        expect(result).toEqual({ success: true });
      }
    });
  });
});

describe("Admin Router", () => {
  describe("admin.getAnalytics", () => {
    it("should require admin role", async () => {
      const caller = appRouter.createCaller({
        user: {
          id: 1,
          openId: "test-user",
          email: "test@example.com",
          name: "Test User",
          loginMethod: "test",
          role: "user",
          createdAt: new Date(),
          updatedAt: new Date(),
          lastSignedIn: new Date(),
        },
        req: {} as any,
        res: {} as any,
      });

      try {
        await caller.admin.getAnalytics();
        expect.fail("Should throw error for non-admin user");
      } catch (error: any) {
        expect(error.message).toBe("Unauthorized");
      }
    });

    it("should return analytics for admin user", async () => {
      const caller = appRouter.createCaller({
        user: {
          id: 1,
          openId: "admin-user",
          email: "admin@example.com",
          name: "Admin User",
          loginMethod: "test",
          role: "admin",
          createdAt: new Date(),
          updatedAt: new Date(),
          lastSignedIn: new Date(),
        },
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.admin.getAnalytics();
      expect(Array.isArray(result)).toBe(true);
    });
  });
});

describe("Auth Router", () => {
  describe("auth.me", () => {
    it("should return null for unauthenticated user", async () => {
      const caller = appRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.auth.me();
      expect(result).toBeNull();
    });

    it("should return user data for authenticated user", async () => {
      const testUser = {
        id: 1,
        openId: "test-user",
        email: "test@example.com",
        name: "Test User",
        loginMethod: "test",
        role: "user" as const,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      const caller = appRouter.createCaller({
        user: testUser,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.auth.me();
      expect(result).toEqual(testUser);
    });
  });

  describe("auth.logout", () => {
    it("should clear session cookie", async () => {
      const clearedCookies: any[] = [];

      const caller = appRouter.createCaller({
        user: {
          id: 1,
          openId: "test-user",
          email: "test@example.com",
          name: "Test User",
          loginMethod: "test",
          role: "user",
          createdAt: new Date(),
          updatedAt: new Date(),
          lastSignedIn: new Date(),
        },
        req: {
          protocol: "https",
          headers: {},
        } as any,
        res: {
          clearCookie: (name: string, options: any) => {
            clearedCookies.push({ name, options });
          },
        } as any,
      });

      const result = await caller.auth.logout();

      expect(result).toEqual({ success: true });
      expect(clearedCookies.length).toBe(1);
      expect(clearedCookies[0].name).toBe("app_session_id");
    });
  });
});
